import React, { useState } from "react";
import axios from "axios";

export default function Home() {
  const [file, setFile] = useState(null);
  const [jobDesc, setJobDesc] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError("Please select a PDF resume to upload.");
      return;
    }
    setError("");
    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);
    if (jobDesc) formData.append("job_description", jobDesc);

    try {
      const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
      const res = await axios.post(`${backendUrl}/analyze`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setResult(res.data);
    } catch (err) {
      console.error(err);
      setError(err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow">
        <h1 className="text-2xl font-bold mb-4">Resume Analyzer</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Upload Resume (PDF)</label>
            <input
              type="file"
              accept="application/pdf"
              onChange={(e) => setFile(e.target.files[0])}
              className="mt-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Job description (optional)</label>
            <textarea
              value={jobDesc}
              onChange={(e) => setJobDesc(e.target.value)}
              rows={4}
              placeholder="Paste target job description to compare missing skills..."
              className="mt-2 w-full border rounded p-2"
            />
          </div>

          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            disabled={loading}
          >
            {loading ? "Analyzing..." : "Analyze Resume"}
          </button>
        </form>

        {error && <p className="mt-4 text-red-600">{String(error)}</p>}

        {result && (
          <div className="mt-6 space-y-4">
            <div className="p-4 border rounded">
              <h2 className="font-semibold">Score: <span className="text-lg">{result.score}/10</span></h2>
              <p className="mt-2"><strong>Summary:</strong> {result.summary}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border rounded">
                <h3 className="font-semibold">Skills</h3>
                <ul className="mt-2 space-y-1">
                  {result.skills.length ? result.skills.map((s) => <li key={s} className="text-sm">{s}</li>) : <li className="text-sm text-gray-500">No skills detected</li>}
                </ul>
              </div>

              <div className="p-4 border rounded">
                <h3 className="font-semibold">Projects</h3>
                <ul className="mt-2 space-y-1">
                  {result.projects.length ? result.projects.map((p, i) => <li key={i} className="text-sm">{p}</li>) : <li className="text-sm text-gray-500">No projects detected</li>}
                </ul>
              </div>

              <div className="p-4 border rounded">
                <h3 className="font-semibold">Keywords</h3>
                <div className="mt-2 flex flex-wrap gap-2">
                  {result.keywords.map((k) => <span key={k} className="text-xs bg-gray-100 px-2 py-1 rounded">{k}</span>)}
                </div>
              </div>
            </div>

            <div className="p-4 border rounded">
              <h3 className="font-semibold">Suggestions</h3>
              <div className="mt-2">
                {result.suggestions.map((s, i) => <p key={i} className="text-sm mt-1">{s}</p>)}
              </div>
            </div>

            {result.missing_skills && (
              <div className="p-4 border rounded">
                <h3 className="font-semibold">Missing Skills (vs job description)</h3>
                {result.missing_skills.length ? (
                  <ul className="mt-2">
                    {result.missing_skills.map((m) => <li key={m} className="text-sm">{m}</li>)}
                  </ul>
                ) : <p className="text-sm text-gray-500 mt-2">None detected — your resume already includes the listed skills.</p>}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
