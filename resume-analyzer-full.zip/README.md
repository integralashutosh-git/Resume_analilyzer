# Resume Analyzer 🚀

An AI-powered webapp that analyzes resumes:
- Extracts **skills, projects, keywords**
- Rates resume clarity & impact (out of 10)
- Generates a **2-line professional summary**
- Suggests improvements
- (Optional) Compares resume against a **target job description**

Built with:
- **Frontend** → Next.js + TailwindCSS
- **Backend** → FastAPI + PDF/NLP + OpenAI API
- **Dockerized** for easy deployment

## Quickstart (Docker)

1. Clone this repo
2. Set your OpenAI key:
   ```bash
   export OPENAI_API_KEY="your_openai_api_key"
   ```
3. Build & run:
   ```bash
   docker-compose up --build
   ```
4. Open: http://localhost:3000

## Local (without Docker)

### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="your_openai_api_key"
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Notes
- Replace the placeholder model in utils.py if you want to use a different OpenAI model.
- Improve extraction logic with spaCy / language_tool_python.
