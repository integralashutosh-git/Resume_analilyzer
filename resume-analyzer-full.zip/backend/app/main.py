# backend/app/main.py
import os
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from typing import Optional
from .utils import (
    extract_text_from_pdf,
    extract_skills_and_projects,
    rate_resume,
    call_openai_summary_and_suggestions,
    compare_with_job,
)

app = FastAPI(title="Resume Analyzer API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # change in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeResponse(BaseModel):
    text: str
    skills: list
    projects: list
    keywords: list
    score: float
    summary: str
    suggestions: list
    missing_skills: Optional[list] = None


@app.post("/analyze", response_model=AnalyzeResponse)
async def analyze(
    file: UploadFile = File(...),
    job_description: Optional[str] = Form(None)
):
    # 1. Read file bytes
    contents = await file.read()
    text = extract_text_from_pdf(contents)

    # 2. Extract skills/projects/keywords
    skills, projects, keywords = extract_skills_and_projects(text)

    # 3. Score resume
    score = rate_resume(text, skills, projects)

    # 4. LLM calls for summary & suggestions
    summary, suggestions = call_openai_summary_and_suggestions(text, skills, projects, keywords)

    missing_skills = None
    if job_description:
        missing_skills = compare_with_job(skills, job_description)

    return {
        "text": text,
        "skills": skills,
        "projects": projects,
        "keywords": keywords,
        "score": score,
        "summary": summary,
        "suggestions": suggestions,
        "missing_skills": missing_skills
    }


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=int(os.getenv('PORT',8000)), reload=True)
