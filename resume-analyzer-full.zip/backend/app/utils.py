# backend/app/utils.py
import io
import json
import re
from typing import Tuple, List
import pdfplumber
from collections import Counter
import os
import openai

# Load a small skills list; extend as needed
SKILLS_FILE = os.path.join(os.path.dirname(__file__), "skills.json")
with open(SKILLS_FILE, "r", encoding="utf-8") as f:
    KNOWN_SKILLS = json.load(f)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

def extract_text_from_pdf(file_bytes: bytes) -> str:
    text_chunks = []
    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_chunks.append(page_text)
    text = "\n".join(text_chunks)
    # basic normalization
    text = re.sub(r"\n{2,}", "\n", text)
    return text

def extract_skills_and_projects(text: str) -> Tuple[List[str], List[str], List[str]]:
    # Find skills by scanning for known skills (case-insensitively)
    lower = text.lower()
    found_skills = []
    for s in KNOWN_SKILLS:
        if s.lower() in lower:
            found_skills.append(s)

    # Very simple project extraction: look for lines containing "Project" or verbs like built/developed
    project_pattern = re.compile(r"((?:project[:\s].{10,200})|(?:built .*?|developed .*?|led .*?project.*?|implemented .*?))", re.I)
    raw_projects = project_pattern.findall(text)
    # flatten and clean
    projects = [p[0] if isinstance(p, tuple) else p for p in raw_projects]
    projects = list(dict.fromkeys([p.strip() for p in projects if p]))[:10]

    # Keywords: top terms by frequency excluding stopwords (simple)
    words = re.findall(r"[A-Za-z\+\#\-\.]{2,}", text)
    words = [w.lower() for w in words]
    stopwords = set(["and","the","with","for","in","on","a","an","to","of","as","by","at","from","is","are","i","we","our","this","that"])
    words = [w for w in words if w not in stopwords and not w.isdigit()]
    freq = Counter(words)
    keywords = [w for w, _ in freq.most_common(20) if len(w) > 2][:15]

    return found_skills, projects, keywords

def rate_resume(text: str, skills: list, projects: list) -> float:
    # Basic heuristic scoring out of 10
    score = 5.0
    # clarity: length between 200 and 1200 words (reward)
    num_words = len(text.split())
    if 250 <= num_words <= 1200:
        score += 1.5
    elif 1200 < num_words <= 2000:
        score += 0.5
    # skills density
    if len(skills) >= 5:
        score += 1.5
    elif 2 <= len(skills) < 5:
        score += 0.8
    # projects
    if len(projects) >= 2:
        score += 1.0
    elif len(projects) == 1:
        score += 0.3
    # action verbs presence
    action_verbs = ["led", "implemented", "designed", "built", "developed", "improved", "optimized"]
    if any(v in text.lower() for v in action_verbs):
        score += 1.0
    final = min(round(score, 1), 10.0)
    return final

def call_openai_summary_and_suggestions(text: str, skills: list, projects: list, keywords: list):
    """
    Make a single ChatCompletion call to produce a 2-line summary and suggestions.
    """
    if OPENAI_API_KEY is None:
        # fallback
        return ("[API key not set: summary unavailable]", ["Set OPENAI_API_KEY in backend environment variables."])
    prompt = f"""
You are a career coach AI. Given the resume text below, do the following:
1) Provide a concise professional summary in exactly 2 short sentences (each sentence should be short — candidate-style).
2) Provide up to 5 actionable suggestions to improve clarity and impact. Number them.

Resume text:
"""{text[:6000]}"""

Extracted skills: {skills}
Extracted projects: {projects}
Keywords: {keywords}
"""
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role":"user","content":prompt}],
            max_tokens=400,
            temperature=0.2
        )
        content = resp["choices"][0]["message"]["content"].strip()
        parts = content.split("\n\n", 1)
        summary = parts[0].replace("\n", " ").strip()
        suggestions = []
        if len(parts) > 1:
            suggestions = [line.strip() for line in parts[1].splitlines() if line.strip()]
        return summary, suggestions
    except Exception as e:
        return (f"[OpenAI error: {e}]", [f"Error calling OpenAI: {e}"])

def compare_with_job(skills: list, job_description: str) -> List[str]:
    # naive approach: look for skill names in job_description; missing = known_skills in job but not in resume
    found_in_job = []
    jd = job_description.lower()
    for s in KNOWN_SKILLS:
        if s.lower() in jd:
            found_in_job.append(s)
    missing = [s for s in found_in_job if s not in skills]
    return missing
